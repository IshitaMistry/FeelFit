package com.example.feelfit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Exercise_details_six : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise_details_six)
    }
}