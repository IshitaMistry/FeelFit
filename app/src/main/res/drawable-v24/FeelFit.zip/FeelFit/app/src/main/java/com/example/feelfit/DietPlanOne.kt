package com.example.feelfit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DietPlanOne : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diet_plan_one)
    }
}